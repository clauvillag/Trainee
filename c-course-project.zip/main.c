/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int AnoActual = 2025;


#define PRECIO_HORAS_EXTRA 60
#define BONOA 200


int main()
{
   int edad;
   float SueldoAnual;
   char Departamento;
   int AnoDeNacimiento;
   int HoraExtraTrabajada;
   float PagoTotal;
   
   
   printf ("A continuacion, le pediremos sus datos personales. \n\n");
   
   printf ("¿Que edad tiene? : \n");
   scanf ("%d",&edad);
   
   AnoDeNacimiento = AnoActual - edad;
   
   printf ("Naciste en el año %d!\n ",AnoDeNacimiento);
   
   printf("¿Cual es su sueldo anual? :\n");
   scanf("%f",&SueldoAnual);
   
   printf("¿A que Departamento pertenece? : \n");
   scanf(" %c",&Departamento);
   
   if (Departamento == 'A' || Departamento == 'a') {printf ("Excelente. Recibirás un bono de %d. \n ",BONOA);}
   
   printf("¿Cuantas horas extras trabajaste?: \n");
   scanf ("%d",&HoraExtraTrabajada);

   PagoTotal = (SueldoAnual/12)+(PRECIO_HORAS_EXTRA*HoraExtraTrabajada);
   
 if (Departamento == 'A' || Departamento == 'a') { PagoTotal =  (SueldoAnual/12)+(PRECIO_HORAS_EXTRA*HoraExtraTrabajada) + BONOA;}
  
    printf ("Cobrarás este mes : %.2f  \n",PagoTotal);
    
 return 0;
}